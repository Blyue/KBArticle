﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace KBArticleBot
{
    public class BingSearch
    {
        public static async Task<SearchResult> MakeRequest(string query)
        {

            SearchResult json = new SearchResult();
            using (HttpClient client = new HttpClient())
            {

                var queryString = HttpUtility.ParseQueryString(string.Empty);
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "ba14e7ae3f1a4085b549ab33f5cf0c97");
                queryString["q"] = query;
                queryString["count"] = "5";
                queryString["offset"] = "0";
                queryString["mkt"] = "en-us";
                queryString["safeSearch"] = "Moderate";
                var uri = "https://api.cognitive.microsoft.com/bing/v5.0/search?q=" + query;
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var JsonDataResponse = await response.Content.ReadAsStringAsync();
                    json = JsonConvert.DeserializeObject<SearchResult>(JsonDataResponse);
                    return json;
                }
            }
            return json;
        }
    }
}